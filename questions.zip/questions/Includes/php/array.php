<?php

//Nav Menu Link Texts

$nav_menu_texts=array

		("Logged_in"=>array(
		"Home"=>"../home.php",
		"Browse"=>"browse.php",
		"Ask"=>"ask.php"),
		
		 "Logged_out"=>array(
		 "Home"=>"../experiences.php",
		 "Browse"=>"browse.php",
		 "Login/Signup"=>"../index.php",
		 ));
?>