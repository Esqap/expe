
	<!-- To Work Media Quires On Mobile -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Bootstrap library -->
	<link rel="stylesheet" href="Includes/css/bootstrap.css">

	<!-- Custom and Responsive CSS Style and -->
	<link rel="stylesheet" href="Includes/css/style.css?t=<?php echo time(); ?>" >
	<link rel="stylesheet" href="Includes/css/responsive.css?t=<?php echo time(); ?>">
	<link rel="stylesheet" href="Includes/js/jqueryui/jquery-ui.min.css?t=<?php echo time(); ?>">

	<!-- JQUERY -->
	<script type="text/javascript" src="Includes/js/jquery.min.js"></script>
	<script type="text/javascript" src="Includes/js/jqueryui/jquery-ui.min.js"></script>

	<!-- Bootsrap JavaScript-->
	<script type="text/javascript" src="Includes/js/bootstrap.min.js"></script>

	<!--Font Awesome-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

