

<!-- To Work Media Quires On Mobile -->

<meta name="viewport" content="width=device-width, initial-scale=1">


<!-- Bootstrap library -->

<link rel="stylesheet" href="Includes/css/bootstrap.css">



<!-- Custom and Responsive CSS Style and -->

<link rel="stylesheet" href="Includes/css/style.css?t=<?php echo time(); ?>" >

<link rel="stylesheet" href="Includes/js/jqueryui/jquery-ui.min.css?t=<?php echo time(); ?>" >

<link rel="stylesheet" href="Includes/css/responsive.css?t=<?php echo time(); ?>">



<script type="text/javascript" src="Includes/js/jquery.min.js?t=<?php echo time(); ?>"></script>



<!-- jQuery easing plugin -->

<script src="jquery.easing.min.js" type="text/javascript"></script>

<script src="Includes/js/multi_step_script.js" type="text/javascript"></script>

<script type="text/javascript" src="Includes/js/jqueryui/jquery-ui.min.js?t=<?php echo time(); ?>"></script>


<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">


<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">











