
    <!---Footeer Start ---->
	<nav  class="navbar navbar-primary" style="border-radius:0; margin:0; background:#204d74; color:white!important; bottom: 0px; width: 100%;">
		<div class="container" >
			<div class="collapse navbar-collapse">
				<ul class="nav navbar-nav text-right" style="float:none; margin:0 auto; display:table;">
						<li><a style="color:white;" href="about_exp.php">About Us</a></li>
						<li><a style="color:white;" href="privacy_policy.php">Privacy Policy</a></li>	
						<li><a style="color:white;" href="terms_conditions.php">Terms & Conditions</a></li>	
				</ul>
			</div>
		</div><!--End Container -->
	</nav>